import knex from 'knex';

const db = knex({
    client: 'mysql',
    connection: {
        host: "somethingsold-db.cr6o0assuiva.us-east-1.rds.amazonaws.com",
        user: "admin",
        password: "somethingsold123",
        port: "3306",
        database: "somethingsold"
    }
});

export const handler = async (event) => {
    const response = {
        statusCode: 200,
        body: null,
    };

    const { id, name, price, dimensions, condition, image_path, seller_id, buyer_id, availability_date } = JSON.parse(event.body);

    try {
        await db('item').insert({
            id,
            name,
            price,
            dimensions,
            condition,
            image_path,
            seller_id,
            buyer_id,
            availability_date
        });
        response.body = JSON.stringify({ message: "Item created successfully" });
    } catch (error) {
        response.statusCode = 500;
        response.body = JSON.stringify({ error: error.message });
    }

    return response;
};
